package com.kh.model;

import lombok.NoArgsConstructor;
import lombok.Data;

@Data @NoArgsConstructor
public class Member {

	private String id;
	private String password;
	private String name;

}
