package config;

public interface ServerInfo {

	String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";

	String URL = "jdbc:mysql://localhost:3306/sample";
	String USER = "root";
	String PASSWORD = "qwer1234";
}
