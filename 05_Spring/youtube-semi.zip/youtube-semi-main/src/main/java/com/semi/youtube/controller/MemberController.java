package com.semi.youtube.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MemberController {
	// 회원가입
	
	// 로그인
}
