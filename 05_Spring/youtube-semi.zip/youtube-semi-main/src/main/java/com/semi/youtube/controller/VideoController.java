package com.semi.youtube.controller;

public class VideoController {

	// 비디오 전체 목록 보기
	
	// 비디오 1개 보여주기
	
	// 댓글 작성
	
	// 댓글 수정
	
	// 댓글 삭제
	
	// 좋아요
	
	// 좋아요 취소
	
	// 구독
	
	// 구독 취소
}
